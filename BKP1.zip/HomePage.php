<?php
require 'HomePage.inc';

$default_pic = "default.jpg";

$menu_elements = array(
	new Layer("id_layer1", "Layer 1", "layer1.jpg", "Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1Layer1"),
	new Layer("id_layer2", "Layer 2", "layer2.jpg", "Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2Layer2"),
	new Layer("id_layer3", "Layer 3", "layer3.jpg", "Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3Layer3"),
	new Layer("id_layer4", "Layer 4", "layer4.jpg", "Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4Layer4"),
	new Layer("id_layer5", "Layer 5", "layer5.jpg", "layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5layer5"),
	new Layer("id_layer6", "Layer 6", "layer6.jpg", "layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6layer6")

	);

  $homepage = new HomePage($default_pic, $menu_elements); 
  $homepage->display();
?>